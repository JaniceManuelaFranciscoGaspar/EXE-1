package com.example.conversorfahrenheit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button btn;
    EditText cel;
    TextView txt1;
    double f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn =findViewById(R.id.btn);
        cel = findViewById(R.id.cel);
        txt1 = findViewById(R.id.txt1);
    }
    public void OnClick(View v)
    {
        Double ce =Double.parseDouble(cel.getText().toString());
        f=ce*1.8 +32;
        txt1.setText(f + "F");

    }

}